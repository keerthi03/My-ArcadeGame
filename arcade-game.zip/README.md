# ARCADE GAME :: REACH THE RIVER
==================================

This is a simple game to help the player reach the river without getting hit by the enemy. No specific eligibility is needed to play this game. Players of any age group can play it. The best browser to play this game is **Google Chrome** though it works in browsers above **Internet Explorer 8**.

## HOW TO RUN THE GAME
=========================

* Go to to the [Udacity] (www.udacity.com) site .

* Go to Projects.

* Download the zip file arcade-game.zip.

* Open the zip file and right click the index.html file and open with _google chrome_.

* Play the game following the instructions.

## INSTRUCTIONS
=================

* Player has 5 lives.

* Move the player using keyboard arrow keys.

* If the player is hit by enemy, player will loose a life  and the game resets.

* If the player losses all its 5 lives then the game is over.

* If the player reaches the river before the player looses its life then Player wins.

## SUPPORT
============

If you have any queries regarding the game please mail us at _dianaj@gamil.com_.

## LICENSE
============

This project is licensed under the ABC license.


